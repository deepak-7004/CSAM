'use strict';

module.exports = (sequelize, DataTypes) => {
  const goodReads = sequelize.define(
    'goodReads',
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
      },
      name: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      background_type: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
      },
      status: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
      },
      year_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      background_image: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      good_read_content: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
    },
    {
      tableName: 'good_reads',
      timestamps: false,
    },
  );

  return goodReads;
};
