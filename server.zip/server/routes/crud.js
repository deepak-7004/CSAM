const express = require('express');
const router = express.Router();
const models = require('../models');
const crudController = require('../controllers/crudController');
const { checkPermissions } = require('../middleware/auth.js');

router.get(
  '/landing-pages',
  checkPermissions(['browse_landing_page']),
  crudController(models.landing_page).getAll,
);
router.get(
  '/good-reads',
  checkPermissions(['browse_good_reads']),
  crudController(models.good_reads).getAll,
);

module.exports = (app) => {
  app.use('/api/crud', router);
};
