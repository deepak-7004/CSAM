<!-- Please run these commands before pushing the code -->

npx eslint --fix .
npx prettier --write .