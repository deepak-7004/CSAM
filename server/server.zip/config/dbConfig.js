const config = {
    database: 'csam',
    username: 'root',
    password: '',
    host: 'localhost',
    dialect: 'mysql', 
  };
  
  module.exports = config;
  