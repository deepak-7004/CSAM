const express = require('express');
const router = express.Router();
const models = require('../models');
const crudController = require('../controllers/crudController');
const { checkPermissions } = require('../middleware/auth.js');

router.get(
  '/landing-pages',
  checkPermissions(['browse_landing_page']),
  crudController(models.landing_page).getAll,
);

// router.get(
//   '/good-reads',
//   // checkPermissions(['browse_landing_page']),
//   crudController(models.good_reads).getAll,
// );

router.get(
  '/good-reads-and-newsletter',
  async (req, res, next) => {
    try {
      const [goodReadsData, newsletterData] = await Promise.all([
        models.good_reads.findAll(),
        models.good_reed_newsletter.findAll(),
      ]);

      // Send data as an object with separate properties
      res.json({
        goodReadsData,
        newsletterData,
      });

    } catch (error) {
      next(error);
    }
  }
);

// router.get(
//   '/good-reads',
//   crudController(models.good_reads).getAll,
// );

module.exports = (app) => {
  app.use('/api/crud', router);
};
